﻿CREATE PROCEDURE [dbo].[usp_DeleteBook]
	@p_Id INT
AS

SET XACT_ABORT, NOCOUNT ON

BEGIN
	DELETE FROM [dbo].[Book]
	WHERE [Id] = @p_Id
END