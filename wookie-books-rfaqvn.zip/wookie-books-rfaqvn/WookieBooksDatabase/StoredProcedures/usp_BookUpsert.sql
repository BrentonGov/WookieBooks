﻿CREATE PROCEDURE [dbo].[usp_BookUpsert]
	@p_Id INT = NULL,
	@p_UserId INT = NULL,
	@p_Title VARCHAR(300) = NULL,
	@p_Description VARCHAR(500) = NULL,	
	@p_CoverImage VARCHAR(500) = NULL,
	@p_Price DECIMAL(10,2) = NULL

AS

SET XACT_ABORT, NOCOUNT ON
DECLARE @starttrancount INT
BEGIN

	IF(@p_Id IS NULL)
	BEGIN
		INSERT INTO [dbo].[Book]
		(
			[UserId],
			[Title],
			[Description],
			[CoverImage],
			[Price]
		)
		VALUES
		(
			@p_UserId,
			@p_Title,
			@p_Description,
			@p_CoverImage,
			@p_Price
		)

		SELECT CAST(SCOPE_IDENTITY() AS INT)
	END
	ELSE
	BEGIN
		UPDATE [dbo].[Book]
		SET 
			[Title] = COALESCE(@p_Title, [Title]),
			[Description] = COALESCE(@p_Description, [Description]),
			[CoverImage] = COALESCE(@p_CoverImage, [CoverImage]),
			[Price] = COALESCE(@p_Price, [Price])
		WHERE [Id] = @p_Id

		SELECT @p_Id		
	END

END