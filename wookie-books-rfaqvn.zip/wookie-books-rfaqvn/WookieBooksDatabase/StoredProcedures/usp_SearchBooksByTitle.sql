﻿CREATE PROCEDURE [dbo].[usp_SearchBooksByTitle]
@p_Title varchar(300) = NULL
AS

SET XACT_ABORT, NOCOUNT ON

BEGIN

	IF(@p_Title IS NOT NULL)
		BEGIN
			SELECT book.[Id], usertab.[Author], book.[Title], book.[Description], book.[CoverImage], book.[Price]
			FROM [dbo].[Book] book
			JOIN [dbo].[User] usertab ON book.[UserId] = usertab.[Id]
			WHERE book.[Title] LIKE '%' + @p_Title + '%'
		END

	ELSE
		BEGIN
			SELECT book.[Id], usertab.[Author], book.[Title], book.[Description], book.[CoverImage], book.[Price]
			FROM [dbo].[Book] book
			JOIN [dbo].[User] usertab ON book.[UserId] = usertab.[Id]

		END

END
GO


