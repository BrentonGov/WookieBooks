﻿CREATE PROCEDURE [dbo].[usp_GetBookById]
@p_Id int 

AS

SET XACT_ABORT, NOCOUNT ON

BEGIN

SELECT 
	 book.[Id], usertab.[Author], book.[Title], book.[Description], book.[CoverImage], book.[Price]
FROM [dbo].[Book] book
JOIN [dbo].[User] usertab ON book.[UserId] = usertab.[Id]
WHERE book.[Id] = @p_Id

END
GO


