﻿CREATE PROCEDURE [dbo].[usp_GetUserByEmail]
	@p_Email varchar(150)
WITH ENCRYPTION
AS

SET XACT_ABORT, NOCOUNT ON

BEGIN

OPEN SYMMETRIC KEY EncryptModel_Key
DECRYPTION BY CERTIFICATE [WookieCert]

SELECT 
		[Id], [Email], CONVERT(VARCHAR, DECRYPTBYKEY([Password], 1, HASHBYTES('SHA1', CONVERT(VARBINARY, CONVERT(VARCHAR, [Email]))))) AS 'Password', [Author], [AllowPublishing]
FROM	[dbo].[User]
WHERE	[Email] = @p_Email

END

GO


