CREATE MASTER KEY ENCRYPTION BY 
PASSWORD = 'PasswordEquals=GodOfDatabases'
GO

CREATE CERTIFICATE [WookieCert] WITH SUBJECT = 'Wookie Certificate'

GO

CREATE SYMMETRIC KEY EncryptModel_Key
WITH ALGORITHM = AES_256
ENCRYPTION BY CERTIFICATE [WookieCert]

GO

OPEN SYMMETRIC KEY EncryptModel_Key
DECRYPTION BY CERTIFICATE [WookieCert]
GO

INSERT INTO [dbo].[User]
           ([Email]
           ,[Password]
           ,[Author]
           ,[AllowPublishing])
     VALUES
           ('brenton.gov1@gmail.com',ENCRYPTBYKEY(KEY_GUID('EncryptModel_Key'), 'P@@sword', 1, HASHBYTES('SHA1', CONVERT(VARBINARY, 'brenton.gov1@gmail.com'))), 'Brenton_Govender', 1),
		   ('usertest@gmail.com',ENCRYPTBYKEY(KEY_GUID('EncryptModel_Key'), 'darthPass', 1, HASHBYTES('SHA1', CONVERT(VARBINARY, 'usertest@gmail.com'))),'_Darth Vader_', 0)
GO

INSERT INTO [dbo].[Book]
           ([UserId]
           ,[Title]
           ,[Description]
           ,[CoverImage]
           ,[Price])
     VALUES
           ((select Id from dbo.[User] where email ='brenton.gov1@gmail.com')
           ,'Great Book'
           ,'A Great Book'
           ,'/PathToImage'
           ,55.99),
		   ((select Id from dbo.[User] where email ='usertest@gmail.com')
           ,'Another Book'
           ,'A nother Book'
           ,'/PathToImage2'
           ,90.99)
GO


