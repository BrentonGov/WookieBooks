﻿using WookieBooks.API.Controllers.Base;
using Domain.Entities;
using Microsoft.AspNetCore.Mvc;
using Application.Books.Queries.SearchBooksByTitle;
using Application.Books.Queries.GetBook;

namespace WookieBooks.API.Controllers
{
    public class BooksController : ApiControllerBase
    {
        [HttpGet]
        public async Task<ActionResult<IList<SearchBooksDTO>>> Search([FromQuery]string? title)
        {
            return await Mediator.Send(new SearchBooksByTitleQuery() { Title = title});
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<GetBookDTO>> Get(int id)
        {
            return await Mediator.Send(new GetBookByIdQuery(id));
        }

    }
}
