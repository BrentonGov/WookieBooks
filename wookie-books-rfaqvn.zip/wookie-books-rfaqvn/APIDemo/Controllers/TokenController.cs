﻿using Application.Tokens.Queries;
using Microsoft.AspNetCore.Mvc;
using WookieBooks.API.Controllers.Base;

namespace WookieBooks.API.Controllers
{
    public class TokenController : ApiControllerBase
    {
        [HttpPost]
        public async Task<ActionResult<string>> Post(string email, string password)
        {
            return await Mediator.Send(new RequestTokenQuery() { Email = email, Password = password });
        }

    }
}
