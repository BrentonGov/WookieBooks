﻿using Application.Books.Commands.CreateBook;
using Application.Books.Commands.DeleteBook;
using Application.Books.Commands.UpdateBook;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WookieBooks.API.Controllers.Base;

namespace WookieBooks.API.Controllers
{
    [Authorize]
    public class AuthenticatedBooksController : ApiControllerBase
    {

        [HttpPost]
        public async Task<ActionResult<int>> Create(CreateBookCommand command)
        {
            return await Mediator.Send(command);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Update(int id, UpdateBookCommand command)
        {
            if (id != command.Id)
            {
                return BadRequest();
            }

            await Mediator.Send(command);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await Mediator.Send(new DeleteBookCommand(id));

            return NoContent();
        }
    }
}
