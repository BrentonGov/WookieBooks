﻿using Application.Books.Queries.GetBook;
using Application.Books.Queries.SearchBooksByTitle;
using Application.Common.Interfaces;
using Dapper;
using Domain.Entities;
using Infrastructure.BaseProvider;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure
{
    public class BookDataProvider : BaseDataProvider<BookDataProvider>, IBookDataProvider
    {
        public BookDataProvider(IConfiguration configuration, ILogger<BookDataProvider> logger) : base(configuration, logger)
        {
            
        }

        public async Task<GetBookDTO> GetBookById(int Id)
        {
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add(Constants.Parameters.Id, Id);

            return await ExecuteSQLAsync(async (SqlConnection conn) =>
            {

                return await conn.QueryFirstOrDefaultAsync<GetBookDTO>(
                    Constants.StoredProcedures.GetBookById,
                    dynamicParameters,
                    commandType: CommandType.StoredProcedure
                    );
            });
        }

        public async Task<IEnumerable<SearchBooksDTO>> SearchBooksByTitleAsync(string? title)
        {
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add(Constants.Parameters.Title, title);

            return await ExecuteSQLAsync(async (SqlConnection conn) =>
            {
                 return await conn.QueryAsync<SearchBooksDTO>(
                        Constants.StoredProcedures.SearchBooksByTitle, 
                        dynamicParameters,
                        commandType: CommandType.StoredProcedure);
            });
        }

        public async Task<int> BookUpsert(Book book)
        {
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add(Constants.Parameters.Id, book.Id);
            dynamicParameters.Add(Constants.Parameters.UserId, book.UserId);
            dynamicParameters.Add(Constants.Parameters.Title, book.Title);
            dynamicParameters.Add(Constants.Parameters.Description, book.Description);
            dynamicParameters.Add(Constants.Parameters.CoverImage, book.CoverImage);
            dynamicParameters.Add(Constants.Parameters.Price, book.Price);

            return await ExecuteSQLAsync(async (SqlConnection conn) =>
            {
                return await conn.QueryFirstOrDefaultAsync<int>(
                       Constants.StoredProcedures.BookUpsert, 
                       dynamicParameters, 
                       commandType: CommandType.StoredProcedure);
            });
        }

        public async Task DeleteBook(int Id)
        {
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add(Constants.Parameters.Id, Id);

            await ExecuteSQLAsync(async (SqlConnection conn) =>
            {
                await conn.QueryAsync(
                       Constants.StoredProcedures.DeleteBook,
                       dynamicParameters,
                       commandType: CommandType.StoredProcedure);
            });
        }

    }
}
