﻿using Application.Common.Interfaces;
using Dapper;
using Domain.Entities;
using Infrastructure.BaseProvider;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure
{
    public class UserDataProvider : BaseDataProvider<UserDataProvider>, IUserDataProvider
    {
        public UserDataProvider(IConfiguration configuration, ILogger<UserDataProvider> logger) : base(configuration, logger)
        {

        }
        public async Task<User> GetUserByEmail(string email)
        {
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add(Constants.Parameters.Email, email);

            return await ExecuteSQLAsync(async (SqlConnection conn) =>
            {

                return await conn.QueryFirstOrDefaultAsync<User>(
                    Constants.StoredProcedures.GetUserByEmail,
                    dynamicParameters,
                    commandType: CommandType.StoredProcedure
                    );
            });
        }
    }
}
