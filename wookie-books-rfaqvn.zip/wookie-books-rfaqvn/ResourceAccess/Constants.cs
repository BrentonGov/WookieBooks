﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure
{
    public class Constants
    {
        public class StoredProcedures
        {
            //Book
            public const string SearchBooksByTitle = "dbo.usp_SearchBooksByTitle";
            public const string GetBookById = "dbo.usp_GetBookById";
            public const string BookUpsert = "dbo.usp_BookUpsert";
            public const string DeleteBook = "dbo.usp_DeleteBook";

            //User
            public const string GetUserByEmail = "dbo.usp_GetUserByEmail";
        }

        public class Parameters
        {
            //Book
            public const string Id = "@p_Id";
            public const string UserId = "@p_UserId";
            public const string Title = "@p_Title";
            public const string Description = "@p_Description";
            public const string CoverImage = "@p_CoverImage";
            public const string Price = "@p_Price";

            //User
            public const string Email = "@p_Email";
        }
    }
}
