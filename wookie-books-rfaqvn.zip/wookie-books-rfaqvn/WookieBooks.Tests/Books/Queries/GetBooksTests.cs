﻿using Application.Books.Queries.GetBook;
using Application.Books.Queries.SearchBooksByTitle;
using FluentAssertions;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WookieBooks.Tests.Books.Queries
{
    using static Testing;
    public class GetBooksTests
    {
        [Test]
        public async Task ShouldReturnAllBooks()
        {
            var query = new SearchBooksByTitleQuery();

            var result = await SendAsync(query);

            result.Should().NotBeEmpty();
        }

        [Test]
        public async Task ShouldReturnBookDetail()
        {
            var query = new GetBookByIdQuery(1);

            var result = await SendAsync(query);

            result.Title.Equals("Great Book");
        }
    }
}
