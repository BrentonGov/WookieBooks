﻿using NUnit.Framework;
using System.Threading.Tasks;

namespace WookieBooks.Tests;

using static Testing;

[TestFixture]
public abstract class BaseTestFixture
{
    [SetUp]
    public async Task TestSetUp()
    {
        await ResetState();
    }
}
