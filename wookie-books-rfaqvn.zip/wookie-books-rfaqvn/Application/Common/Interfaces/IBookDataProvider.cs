﻿using Application.Books.Queries.GetBook;
using Application.Books.Queries.SearchBooksByTitle;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Interfaces
{
    public interface IBookDataProvider
    {
        Task<IEnumerable<SearchBooksDTO>> SearchBooksByTitleAsync(string? title);
        Task<GetBookDTO> GetBookById(int Id);
        Task<int> BookUpsert(Book book);
        Task DeleteBook(int Id);
    }
}
