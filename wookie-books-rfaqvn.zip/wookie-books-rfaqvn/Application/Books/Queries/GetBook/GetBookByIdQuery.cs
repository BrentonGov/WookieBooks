﻿using Application.Common.Interfaces;
using Domain.Entities;
using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Books.Queries.GetBook
{
    public record GetBookByIdQuery(int Id) : IRequest<GetBookDTO>
    {
    }

    public class GetBookByIdQueryHandler : IRequestHandler<GetBookByIdQuery, GetBookDTO>
    {
        private IBookDataProvider _bookDataProvider;
        private ILogger<GetBookByIdQueryHandler> _logger;
        public GetBookByIdQueryHandler(IBookDataProvider bookDataProvider, ILogger<GetBookByIdQueryHandler> logger)
        {
            _bookDataProvider = bookDataProvider;
            _logger = logger;
        }
        public async Task<GetBookDTO> Handle(GetBookByIdQuery request, CancellationToken cancellationToken)
        {
            try
            {
                return await _bookDataProvider.GetBookById(request.Id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to retrieve book! Exception: {ex}");
                throw;
            }
            
        }
    }
}
