﻿using Application.Common.Interfaces;
using Domain.Entities;
using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Books.Queries.SearchBooksByTitle
{
    public record SearchBooksByTitleQuery : IRequest<List<SearchBooksDTO>>
    {
        public string? Title { get; set; }
    }

    public class SearchBooksByTitleQueryHandler : IRequestHandler<SearchBooksByTitleQuery, List<SearchBooksDTO>>
    {
        private ILogger<SearchBooksByTitleQueryHandler> _logger;
        private IBookDataProvider _bookDataProvider;
        public SearchBooksByTitleQueryHandler(IBookDataProvider bookDataProvider, ILogger<SearchBooksByTitleQueryHandler> logger)
        {
            _logger = logger;
            _bookDataProvider = bookDataProvider;
        }

        public async Task<List<SearchBooksDTO>> Handle(SearchBooksByTitleQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var result = await _bookDataProvider.SearchBooksByTitleAsync(request.Title);
                return result.ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to find books! Exception: {ex}");
                throw;
            }
           
            
        }
    }
}
