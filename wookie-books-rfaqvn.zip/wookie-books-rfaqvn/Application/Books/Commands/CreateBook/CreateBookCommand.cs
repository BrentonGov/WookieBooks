﻿using Application.Common.Exceptions;
using Application.Common.Interfaces;
using Domain.Entities;
using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Books.Commands.CreateBook
{
    public record CreateBookCommand : IRequest<int>
    {
        public string Title { get; set; }
        public string? Description { get; set; }
        public string? CoverImage { get; set; }
        public decimal Price { get; set; }
    }
    public class CreateBookCommandHandler : IRequestHandler<CreateBookCommand, int>
    {
        private ILogger<CreateBookCommandHandler> _logger;
        private IBookDataProvider _bookDataProvider;
        private ICurrentUserService _currentUserService;
        private IUserDataProvider _userDataProvider;

        public CreateBookCommandHandler(ILogger<CreateBookCommandHandler> logger,IBookDataProvider bookDataProvider, ICurrentUserService currentUserService, IUserDataProvider userDataProvider)
        {
            _logger = logger;
            _bookDataProvider = bookDataProvider;
            _currentUserService = currentUserService;
            _userDataProvider = userDataProvider;
        }

        public async Task<int> Handle(CreateBookCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var checkUserId = Int32.TryParse(_currentUserService.UserId, out int currentUserId);
                if (!checkUserId)
                {
                    throw new BadRequestException("Cannot obtain UserId from token! Please refresh token");
                }

                var allowedToPublish = _currentUserService.AllowPublishing;
                if (allowedToPublish == null || string.IsNullOrEmpty(allowedToPublish))
                {
                    throw new BadRequestException("Cannot obtain user details from token! Please refresh token");
                }

                if (allowedToPublish.Equals("False"))
                {
                    throw new BadRequestException($"User is banned from Wookie Books!");
                }

                var book = new Book()
                {
                    Title = request.Title,
                    Description = request.Description,
                    CoverImage = request.CoverImage,
                    Price = request.Price,
                    UserId = currentUserId
                };

                return await _bookDataProvider.BookUpsert(book);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to create book! Exception: {ex}");
                throw;
            }
            
        }
    }
}
