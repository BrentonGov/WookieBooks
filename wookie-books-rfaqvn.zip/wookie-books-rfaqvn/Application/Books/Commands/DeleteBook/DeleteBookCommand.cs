﻿using Application.Common.Exceptions;
using Application.Common.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Books.Commands.DeleteBook
{
    public record DeleteBookCommand(int Id) : IRequest
    {
    }

    public class DeleteBookCommandHandler : IRequestHandler<DeleteBookCommand>
    {
        private ILogger<DeleteBookCommandHandler> _logger;
        private IBookDataProvider _bookDataProvider;
        private ICurrentUserService _currentUserService;
        public DeleteBookCommandHandler(ILogger<DeleteBookCommandHandler> logger, IBookDataProvider bookDataProvider, ICurrentUserService currentUserService)
        {
            _logger = logger;
            _bookDataProvider = bookDataProvider;
            _currentUserService = currentUserService;
        }
        public async Task<Unit> Handle(DeleteBookCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var book = await _bookDataProvider.GetBookById(request.Id);
                if(book is null)
                {
                    throw new BadRequestException($"Book with Id: {request.Id} does not exist!");
                }

                var author = _currentUserService.Author;
                if (author == null || string.IsNullOrEmpty(author))
                {
                    throw new BadRequestException("Cannot obtain Author name from token! Please refresh token");
                }

                if (!book.Author.Equals(author))
                {
                    throw new BadRequestException("Users may only unpublish their own books!");
                }

                await _bookDataProvider.DeleteBook(request.Id);
                return Unit.Value;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to delete book! Exception: {ex}");
                throw;
            }

        }
    }
}
