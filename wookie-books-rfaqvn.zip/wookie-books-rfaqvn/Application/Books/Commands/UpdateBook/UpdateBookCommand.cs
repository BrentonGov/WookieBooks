﻿using Application.Common.Exceptions;
using Application.Common.Interfaces;
using Domain.Entities;
using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Books.Commands.UpdateBook
{
    public record UpdateBookCommand : IRequest<int>
    {
        public int Id { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public string? CoverImage { get; set; }
        public decimal? Price { get; set; }
    }
    public class UpdateBookCommandHandler : IRequestHandler<UpdateBookCommand, int>
    {
        private ILogger<UpdateBookCommandHandler> _logger;
        private IBookDataProvider _bookDataProvider;
        private ICurrentUserService _currentUserService;
        private IUserDataProvider _userDataProvider;

        public UpdateBookCommandHandler(ILogger<UpdateBookCommandHandler> logger, IBookDataProvider bookDataProvider, ICurrentUserService currentUserService, IUserDataProvider userDataProvider)
        {
            _logger = logger;
            _bookDataProvider = bookDataProvider;
            _currentUserService = currentUserService;
            _userDataProvider = userDataProvider;
        }

        public async Task<int> Handle(UpdateBookCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var author = _currentUserService.Author;
                if (author == null || string.IsNullOrEmpty(author))
                {
                    throw new BadRequestException("Cannot obtain Author name from token! Please refresh token");
                }

                var findBook = await _bookDataProvider.GetBookById(request.Id);
                if (findBook is null)
                {
                    throw new BadRequestException($"Book with Id: {request.Id} does not exist!");
                }

                if (!findBook.Author.Equals(author))
                {
                    throw new BadRequestException("Users may only update their own books!");
                }

                var book = new Book()
                {
                    Id = request.Id,
                    Title = request.Title,
                    Description = request.Description,
                    CoverImage = request.CoverImage,
                    Price = request.Price
                };

                return await _bookDataProvider.BookUpsert(book);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Failed to update book! Exception: {ex}");
                throw;
            }

        }
    }
}
