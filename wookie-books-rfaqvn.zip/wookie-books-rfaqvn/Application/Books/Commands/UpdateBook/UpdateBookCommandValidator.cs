﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Books.Commands.UpdateBook
{
    public class UpdateBookCommandValidator : AbstractValidator<UpdateBookCommand>
    {
        public UpdateBookCommandValidator()
        {
            RuleFor(x => x.Id).NotEmpty().NotEqual(0);
            RuleFor(x => x).Must(y => AllFieldsNotNull(y.Title, y.Description, y.CoverImage, y.Price)).WithMessage("Please provide a property to update!");
        }

        private bool AllFieldsNotNull(params object[] objects)
        {
            return objects != null && objects.Any(x => x != null);
        }
    }
}
