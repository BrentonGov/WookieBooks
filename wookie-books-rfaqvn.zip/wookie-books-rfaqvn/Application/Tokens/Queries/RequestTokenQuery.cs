﻿using Application.Common.Exceptions;
using Application.Common.Interfaces;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Application.Tokens.Queries
{
    public record RequestTokenQuery : IRequest<string>
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class RequestTokenQueryHandler : IRequestHandler<RequestTokenQuery, string>
    {
        private IUserDataProvider _userDataProvider;
        private IConfiguration _configuration;
        private IJWTTokenGeneration _jWTTokenGeneration;
        public RequestTokenQueryHandler(IUserDataProvider userDataProvider, IConfiguration configuration, IJWTTokenGeneration jWTTokenGeneration)
        {
            _userDataProvider = userDataProvider;
            _configuration = configuration;
            _jWTTokenGeneration = jWTTokenGeneration;
        }
        public async Task<string> Handle(RequestTokenQuery request, CancellationToken cancellationToken)
        {
            var user = await _userDataProvider.GetUserByEmail(request.Email);
            if (user != null && user.Password.Equals(request.Password))
            {
                return await _jWTTokenGeneration.GenerateJWTToken(user);
            }
            else
            {
                throw new BadRequestException($"User with email:{request.Email} does not exist!");
            }
        }
    }
}
