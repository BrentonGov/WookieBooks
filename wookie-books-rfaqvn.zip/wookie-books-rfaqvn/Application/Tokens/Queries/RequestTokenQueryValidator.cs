﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Tokens.Queries
{
    internal class RequestTokenQueryValidator : AbstractValidator<RequestTokenQuery>
    {
        public RequestTokenQueryValidator()
        {
            RuleFor(x => x.Email).NotEmpty();
            RuleFor(x => x.Password).NotEmpty();
        }
    }
}
